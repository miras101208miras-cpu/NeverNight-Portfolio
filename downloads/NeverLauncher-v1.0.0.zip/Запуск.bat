@echo off
title NeverLauncher
cd /d "%~dp0"
start "" node run.js
exit
