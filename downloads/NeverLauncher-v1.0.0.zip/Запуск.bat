@echo off
cd /d "%~dp0"
start "" node run.js
exit
