const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { Client, Authenticator } = require('minecraft-launcher-core');

let mainWindow = null;
const launcher = new Client();

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1040,
    height: 680,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    backgroundColor: '#090c12',
    icon: path.join(__dirname, 'assets', 'logo.jpg'),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile('index.html');

  // Открывать внешние ссылки в браузере по умолчанию
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // События окна
  ipcMain.on('win-min', () => mainWindow && mainWindow.minimize());
  ipcMain.on('win-max', () => {
    if (!mainWindow) return;
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  });
  ipcMain.on('win-close', () => app.quit());

  // Запуск игры через MCLC
  ipcMain.on('launch-game', async (event, opts) => {
    const rootDir = opts.gameDir || path.join(app.getPath('appData'), '.neverclient');
    const modsDir = path.join(rootDir, 'mods');
    if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir, { recursive: true });

    // Копируем NeverClient.jar в папку mods
    const clientJar = path.join(__dirname, 'assets', 'NeverClient-1.0.0.jar');
    const targetJar = path.join(modsDir, 'NeverClient-1.0.0.jar');
    if (fs.existsSync(clientJar)) {
      try { fs.copyFileSync(clientJar, targetJar); } catch (e) {}
    }

    const launchOpts = {
      authorization: Authenticator.getAuth(opts.nickname || 'NeverPlayer'),
      root: rootDir,
      version: {
        number: opts.versionNumber || '1.21.4',
        type: 'release'
      },
      memory: {
        max: (opts.ram || 4) + 'G',
        min: '2G'
      }
    };

    launcher.on('debug', (e) => console.log('[DEBUG]', e));
    launcher.on('data', (e) => console.log('[GAME]', e));
    launcher.on('progress', (e) => {
      event.sender.send('launch-progress', { type: e.type, task: e.task, current: e.current, total: e.total });
    });
    launcher.on('close', (code) => {
      event.sender.send('game-closed', code);
    });

    try {
      await launcher.launch(launchOpts);
      event.sender.send('game-started');
    } catch (err) {
      console.error('Launch error:', err);
      event.sender.send('launch-error', err.message);
    }
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
