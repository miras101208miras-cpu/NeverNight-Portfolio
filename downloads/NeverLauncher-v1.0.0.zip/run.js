const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn, exec } = require('child_process');
const { Client, Authenticator } = require('minecraft-launcher-core');

const PORT = 34567;
const clients = [];

function broadcast(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  clients.forEach(res => {
    try { res.write(msg); } catch (e) {}
  });
}

function getJavaForVersion(ver) {
  if (ver.startsWith('1.16') || ver.startsWith('1.12') || ver.startsWith('1.8') || ver.startsWith('1.7')) {
    const j8 = 'C:\\Program Files\\Java\\jre1.8.0_51\\bin\\javaw.exe';
    if (fs.existsSync(j8)) return j8;
  }
  if (ver.startsWith('1.17') || ver.startsWith('1.18') || ver.startsWith('1.19') || ver.startsWith('1.20')) {
    const j17 = 'C:\\Program Files\\Java\\jdk-17\\bin\\javaw.exe';
    if (fs.existsSync(j17)) return j17;
  }
  const j21 = 'C:\\Program Files\\Java\\jdk-21\\bin\\javaw.exe';
  if (fs.existsSync(j21)) return j21;

  const oracle = 'C:\\Program Files\\Common Files\\Oracle\\Java\\javapath\\javaw.exe';
  if (fs.existsSync(oracle)) return oracle;

  return undefined;
}

let isLaunching = false;

async function launchMinecraft(opts) {
  if (isLaunching) return { success: false, message: 'Запуск уже выполняется' };
  isLaunching = true;

  const appData = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Application Support' : process.env.HOME);
  const rootDir = opts.gameDir || path.join(appData, '.minecraft');
  const versionsDir = path.join(rootDir, 'versions');
  const requested = opts.versionNumber || '1.21.11';
  let customVersion = null;

  const possibleCustoms = [
    `fabric-loader-0.19.5-${requested}`,
    `Fabric ${requested}-0.19.5`,
    `Fabric ${requested}`,
    `fabric-loader-0.19.3-${requested}`,
    `Fabric ${requested}-0.19.3`,
    `FabricSodium ${requested}`,
    `fabric-loader-0.18.5-${requested}`,
    `Forge ${requested}`,
    requested
  ];

  for (const c of possibleCustoms) {
    if (fs.existsSync(path.join(versionsDir, c))) {
      customVersion = c;
      break;
    }
  }

  console.log(`[NeverLauncher] Запрос версии: ${requested}, выбран профиль: ${customVersion || 'Релиз (ваниль)'}`);
  broadcast('log', `Выбрана версия: ${requested} (профиль: ${customVersion || 'release'})`);

  const launcher = new Client();

  launcher.on('debug', (e) => {
    console.log('[DEBUG]', e);
    broadcast('log', e);
  });

  launcher.on('data', (e) => {
    console.log('[GAME]', e);
    broadcast('log', e);
    broadcast('started', { success: true });
  });

  launcher.on('progress', (e) => {
    broadcast('progress', { type: e.type, task: e.task, current: e.current, total: e.total });
  });

  launcher.on('close', (code) => {
    isLaunching = false;
    broadcast('closed', { code });
  });

  const launchOpts = {
    authorization: Authenticator.getAuth(opts.nickname || 'Miras'),
    root: rootDir,
    version: {
      number: requested.replace(/[^\d.]/g, ''),
      type: 'release',
      custom: customVersion || undefined
    },
    memory: {
      max: (opts.ram || 4) + 'G',
      min: '2G'
    }
  };

  const selectedJava = getJavaForVersion(requested);
  if (selectedJava) {
    launchOpts.javaPath = selectedJava;
    console.log(`[NeverLauncher] Java Runtime: ${selectedJava}`);
  }

  try {
    broadcast('progress', { type: 'init', task: 'Запуск игрового клиента...', current: 100, total: 100 });
    await launcher.launch(launchOpts);
    broadcast('started', { success: true });
    return { success: true };
  } catch (err) {
    isLaunching = false;
    console.error('Launch error:', err);
    broadcast('error', { message: err.message });
    return { success: false, error: err.message };
  }
}

// HTTP Server
const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = parsedUrl.pathname;

  // SSE Stream
  if (pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write('retry: 1000\n\n');
    clients.push(res);
    req.on('close', () => {
      const idx = clients.indexOf(res);
      if (idx !== -1) clients.splice(idx, 1);
    });
    return;
  }

  // API Launch
  if (pathname === '/api/launch' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      let opts = {};
      try { opts = JSON.parse(body); } catch (e) {}
      const result = await launchMinecraft(opts);
      res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify(result));
    });
    return;
  }

  // API Close
  if (pathname === '/api/close' && req.method === 'POST') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true }));
    setTimeout(() => { process.exit(0); }, 300);
    return;
  }

  // Static files
  let filePath = path.join(__dirname, pathname === '/' ? 'index.html' : pathname);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(__dirname, 'index.html');
  }

  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.ico': 'image/x-icon',
    '.jar': 'application/java-archive'
  };

  const contentType = mimeTypes[ext] || 'application/octet-stream';
  const stat = fs.statSync(filePath);
  const range = req.headers.range;

  if (range && ext === '.mp4') {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;
    const chunksize = (end - start) + 1;
    const file = fs.createReadStream(filePath, { start, end });
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': contentType
    });
    file.pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': stat.size,
      'Content-Type': contentType
    });
    fs.createReadStream(filePath).pipe(res);
  }
});

function openAppWindow() {
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
  ];

  const browser = candidates.find(p => fs.existsSync(p));
  const appUrl = `http://127.0.0.1:${PORT}`;
  const profileDir = path.join(process.env.TEMP || 'C:\\Windows\\Temp', 'NeverLauncherProfile');

  if (browser) {
    const args = [
      `--app=${appUrl}`,
      '--window-size=1120,720',
      `--user-data-dir=${profileDir}`,
      '--no-first-run',
      '--no-default-browser-check'
    ];
    const proc = spawn(browser, args, { detached: true, stdio: 'ignore' });
    proc.unref();
  } else {
    exec(`start "" "${appUrl}"`);
  }
}

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log('[NeverLauncher] Порт занят, переподключение...');
    setTimeout(() => {
      try { server.close(); } catch(e) {}
      server.listen(PORT, '127.0.0.1', () => {
        console.log(`[NeverLauncher] Сервер перезапущен: http://127.0.0.1:${PORT}`);
      });
    }, 1200);
  } else {
    console.error('Server error:', err);
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[NeverLauncher] Сервер готов: http://127.0.0.1:${PORT}`);
  openAppWindow();
});
