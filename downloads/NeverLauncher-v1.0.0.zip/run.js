const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn, exec } = require('child_process');
const { Client, Authenticator } = require('minecraft-launcher-core');

const PORT = 34567;
const clients = [];

function broadcast(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  clients.forEach(res => {
    try { res.write(msg); } catch (e) {}
  });
}

// Запуск игры через MCLC
let isLaunching = false;
async function launchMinecraft(opts) {
  if (isLaunching) return { success: false, message: 'Игра уже запускается' };
  isLaunching = true;

  const appData = process.env.APPDATA || (process.platform === 'darwin' ? process.env.HOME + '/Library/Application Support' : process.env.HOME);
  const rootDir = opts.gameDir || path.join(appData, '.neverclient');
  const modsDir = path.join(rootDir, 'mods');

  if (!fs.existsSync(modsDir)) {
    fs.mkdirSync(modsDir, { recursive: true });
  }

  // Копируем NeverClient-1.0.0.jar в папку mods
  const clientJar = path.join(__dirname, 'assets', 'NeverClient-1.0.0.jar');
  const targetJar = path.join(modsDir, 'NeverClient-1.0.0.jar');
  if (fs.existsSync(clientJar)) {
    try {
      fs.copyFileSync(clientJar, targetJar);
      broadcast('log', '✔ NeverClient-1.0.0.jar успешно синхронизирован в папку mods');
    } catch (e) {
      console.error('Ошибка копирования мода:', e);
    }
  }

  const launcher = new Client();

  launcher.on('debug', (e) => {
    console.log('[DEBUG]', e);
    broadcast('log', e);
  });

  launcher.on('data', (e) => {
    console.log('[GAME]', e);
    broadcast('log', e);
  });

  launcher.on('progress', (e) => {
    broadcast('progress', { type: e.type, task: e.task, current: e.current, total: e.total });
  });

  launcher.on('close', (code) => {
    isLaunching = false;
    broadcast('closed', { code });
  });

  const launchOpts = {
    authorization: Authenticator.getAuth(opts.nickname || 'NeverPlayer'),
    root: rootDir,
    version: {
      number: opts.versionNumber || '1.21.4',
      type: 'release'
    },
    memory: {
      max: (opts.ram || 4) + 'G',
      min: '2G'
    }
  };

  try {
    broadcast('progress', { type: 'init', task: 'Подготовка клиента...', current: 10, total: 100 });
    await launcher.launch(launchOpts);
    broadcast('started', { success: true });
    return { success: true };
  } catch (err) {
    isLaunching = false;
    broadcast('error', { message: err.message });
    return { success: false, error: err.message };
  }
}

// HTTP Сервер для локального UI
const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = parsedUrl.pathname;

  // SSE эндпоинт для логов и прогресса
  if (pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write('retry: 1000\n\n');
    clients.push(res);
    req.on('close', () => {
      const idx = clients.indexOf(res);
      if (idx !== -1) clients.splice(idx, 1);
    });
    return;
  }

  // API запуска игры
  if (pathname === '/api/launch' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      let opts = {};
      try { opts = JSON.parse(body); } catch (e) {}
      const result = await launchMinecraft(opts);
      res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify(result));
    });
    return;
  }

  // API закрытия лаунчера
  if (pathname === '/api/close' && req.method === 'POST') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true }));
    setTimeout(() => { process.exit(0); }, 300);
    return;
  }

  // Статические файлы
  let filePath = path.join(__dirname, pathname === '/' ? 'index.html' : pathname);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(__dirname, 'index.html');
  }

  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.jar': 'application/java-archive'
  };

  const contentType = mimeTypes[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      res.end('Not Found');
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[NeverLauncher] Сервер активен: http://127.0.0.1:${PORT}`);

  // Открываем окно в режиме отдельного десктопного приложения (Chromium App Mode)
  const edgePath1 = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  const edgePath2 = 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe';
  const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

  let browserPath = null;
  if (fs.existsSync(edgePath1)) browserPath = edgePath1;
  else if (fs.existsSync(edgePath2)) browserPath = edgePath2;
  else if (fs.existsSync(chromePath)) browserPath = chromePath;

  const appUrl = `http://127.0.0.1:${PORT}`;

  if (browserPath) {
    const browserProcess = spawn(browserPath, [
      `--app=${appUrl}`,
      '--window-size=1060,700',
      '--app-id=neverlauncher'
    ], { detached: true, stdio: 'ignore' });

    browserProcess.unref();
  } else {
    // Резервный вызов стандартного браузера
    exec(`start ${appUrl}`);
  }
});
